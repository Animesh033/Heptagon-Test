<li class="nav-item">
    <a class="nav-link" href="{{ route('companies.index') }}">{{ __('Companies') }}</a>
</li>
<li class="nav-item">
    <a class="nav-link" href="{{ route('employees.index') }}">{{ __('Employees') }}</a>
</li>
