<?php

return [

    'company_bulk_upload_template_file' => env('COMPANY_BULK_UPLOAD_TEMPLATE_FILE', 'heptagon-tempate.xlsx'),

];
