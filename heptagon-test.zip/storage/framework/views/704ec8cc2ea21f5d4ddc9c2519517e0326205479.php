<?php if (isset($component)) { $__componentOriginalc12a2b15f6a025208ed03220d22760b8dfc8f9f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Heptagon\App::class, []); ?>
<?php $component->withName('heptagon.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <h2><?php echo e(isset($pageHeading) ? $pageHeading : ""); ?></h2>
    </div>
    <?php if (isset($component)) { $__componentOriginal15ad0ac9bacdf6c14955e6940ecd573aa704f94f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Heptagon\ValidationError::class, []); ?>
<?php $component->withName('heptagon.validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal15ad0ac9bacdf6c14955e6940ecd573aa704f94f)): ?>
<?php $component = $__componentOriginal15ad0ac9bacdf6c14955e6940ecd573aa704f94f; ?>
<?php unset($__componentOriginal15ad0ac9bacdf6c14955e6940ecd573aa704f94f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php echo e($slot); ?>

 <?php if (isset($__componentOriginalc12a2b15f6a025208ed03220d22760b8dfc8f9f4)): ?>
<?php $component = $__componentOriginalc12a2b15f6a025208ed03220d22760b8dfc8f9f4; ?>
<?php unset($__componentOriginalc12a2b15f6a025208ed03220d22760b8dfc8f9f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\xampp74\htdocs\projects\tests\heptagon-test\resources\views/components/heptagon/layout.blade.php ENDPATH**/ ?>