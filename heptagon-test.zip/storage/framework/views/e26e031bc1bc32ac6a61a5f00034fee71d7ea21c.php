<?php if (isset($component)) { $__componentOriginal1c56f069ac3a2d89e930c69e71d82d82f2f427b8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Heptagon\Layout::class, []); ?>
<?php $component->withName('heptagon.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('pageHeading'); ?> Employee Dashboard <span class="float-right"><a href="<?php echo e(route('companies.index')); ?>"><i class="bi bi-arrow-left-circle-fill"></i></a></span> <?php $__env->endSlot(); ?>
    <div class="container">
    <a href="<?php echo e(route('employees.create')); ?>" class="btn btn-dark">Add Employee</a>
    <div class="row">
        <div class="col-md-12">
            <div class="form-row">
                <div class="col-md-6"><div class="response-message pt-2"></div></div>
            </div>
            <div class="table-responsive h-bg-white">
                <table class="table table-borderless">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">First Name</th>
                            <th scope="col">Last Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Designation</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(isset($employees) && $employees->count()): ?>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($key+1); ?></th>
                                <td><a href="<?php echo e(route('employees.show', $employee->id)); ?>"><?php echo e($employee->first_name); ?></a></td>
                                <td><?php echo e($employee->last_name); ?></td>
                                <td><?php echo e($employee->email); ?></td>
                                <td><?php echo e($employee->phone); ?></td>
                                <td><?php echo e($employee->designation); ?></td>
                                <td><?php echo e($employee->status); ?></td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-light dropdown-toggle" type="button" id="actions" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                          Actions
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="actions">
                                          <a class="dropdown-item" href="<?php echo e(route('employees.show', $employee->id)); ?>">View</a>
                                          <a class="dropdown-item" href="<?php echo e(route('employees.edit', $employee->id)); ?>">Edit</a>
                                          <a class="dropdown-item delete-emp" data-route="<?php echo e(route('employees.destroy', $employee->id)); ?>" href="javascript:void(0)"> <?php echo e(__('Delete')); ?> </a>
                                          
                                            <form class="delete-emp-form" action="<?php echo e(route('employees.destroy', $employee->id)); ?>" method="POST" class="d-none">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                        </div>
                                      </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <th scope="row"><?php echo e(__('Data not found.')); ?></th>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <?php echo e($employees->links()); ?>

            </div>
        </div>
    </div>
</div>
 <?php if (isset($__componentOriginal1c56f069ac3a2d89e930c69e71d82d82f2f427b8)): ?>
<?php $component = $__componentOriginal1c56f069ac3a2d89e930c69e71d82d82f2f427b8; ?>
<?php unset($__componentOriginal1c56f069ac3a2d89e930c69e71d82d82f2f427b8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\xampp74\htdocs\projects\tests\heptagon-test\resources\views/heptagon/admin/employee/index.blade.php ENDPATH**/ ?>