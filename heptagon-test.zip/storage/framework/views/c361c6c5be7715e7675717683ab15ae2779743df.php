<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('companies.index')); ?>"><?php echo e(__('Companies')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('employees.index')); ?>"><?php echo e(__('Employees')); ?></a>
</li>
<?php /**PATH D:\xampp74\htdocs\projects\tests\heptagon-test\resources\views/components/heptagon/admin-menu.blade.php ENDPATH**/ ?>