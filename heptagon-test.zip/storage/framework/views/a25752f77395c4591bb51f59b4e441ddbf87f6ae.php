<?php if (isset($component)) { $__componentOriginal1c56f069ac3a2d89e930c69e71d82d82f2f427b8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Heptagon\Layout::class, []); ?>
<?php $component->withName('heptagon.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
    <h2>Company Dashboard</h2>
    <a href="<?php echo e(route('companies.create')); ?>" class="btn btn-dark">Create Company</a>
    <div class="row">
        <div class="col-md-8">
            <div class="table-responsive h-bg-white">
                <table class="table table-borderless">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Logo</th>
                            <th scope="col">No. of employees</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(isset($companies) && $companies->count()): ?>
                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($key+1); ?></th>
                                <td><a href="<?php echo e(route('companies.show', $company->id)); ?>"><?php echo e($company->name); ?></a></td>
                                <td>
                                    <img src="<?php echo e($company->logo); ?>" class="img-thumbnail"  width="40"
                                    height="40" alt="<?php echo e($company->name); ?>" title="<?php echo e($company->name); ?>">
                                </td>
                                <td><?php echo e($company->employees_count); ?></td>
                                <td><?php echo e($company->status); ?></td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-light dropdown-toggle" type="button" id="actions" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                          Actions
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="actions">
                                          <a class="dropdown-item" href="<?php echo e(route('companies.show', $company->id)); ?>">View</a>
                                          <a class="dropdown-item" href="<?php echo e(route('companies.edit', $company->id)); ?>">Edit</a>
                                          <a class="dropdown-item" href="<?php echo e(route('companies.destroy', $company->id)); ?>" onclick="event.preventDefault();
                                                     document.getElementById('delete-form').submit();"> <?php echo e(__('Delete')); ?> </a>
                                            <form id="delete-form" action="<?php echo e(route('companies.destroy', $company->id)); ?>" method="POST" class="d-none">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                        </div>
                                      </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <th scope="row"><?php echo e(__('Data not found.')); ?></th>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <?php echo e($companies->links()); ?>

            </div>
        </div>
        <div class="col-md-4">
            <form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <label for="">Choose your xls/csv File :</label>
                <div class="input-group mb-3">
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="import" name="excel_file" aria-describedby="import">
                    <label class="custom-file-label" for="import">Choose file</label>
                </div>
                </div>
                <button type="submit" class="btn btn-primary"><i class="bi bi-arrow-up-circle"></i> Bulk Upload</button>
                <button type="button" class="btn btn-outline-dark"><a href="<?php echo e(route('download.template')); ?>" id="downloadTemplate"><b>Download template</b></a></button>
            </form>
        </div>
    </div>
</div>
 <?php if (isset($__componentOriginal1c56f069ac3a2d89e930c69e71d82d82f2f427b8)): ?>
<?php $component = $__componentOriginal1c56f069ac3a2d89e930c69e71d82d82f2f427b8; ?>
<?php unset($__componentOriginal1c56f069ac3a2d89e930c69e71d82d82f2f427b8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\xampp74\htdocs\projects\tests\heptagon-test\resources\views/heptagon/admin/company/index.blade.php ENDPATH**/ ?>