<?php if (isset($component)) { $__componentOriginal1c56f069ac3a2d89e930c69e71d82d82f2f427b8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Heptagon\Layout::class, []); ?>
<?php $component->withName('heptagon.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
    <h2><?php echo e($company->name); ?> Dashboard <span class="float-right"><a href="<?php echo e(route('companies.index')); ?>"><i class="bi bi-arrow-left-circle-fill"></i></a></span></h2>
    <div class="row">
        <div class="col-md-12">
            <div class="table-responsive companyList h-bg-white">
                <table class="table table-borderless company-list">
                    <thead>
                        <tr>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Website</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                            <th scope="col">Logo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(isset($company) && $company): ?>
                            <tr>
                                <td><a href="<?php echo e(route('companies.show', $company->id)); ?>"><?php echo e($company->name); ?></a></td>
                                <td><?php echo e($company->email); ?></td>
                                <td><?php echo e($company->website); ?></td>
                                <td><?php echo e($company->status); ?></td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-light dropdown-toggle" type="button" id="actions" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                          Actions
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="actions">
                                          <a class="dropdown-item" href="<?php echo e(route('companies.show', $company->id)); ?>">View</a>
                                          <a class="dropdown-item" href="<?php echo e(route('companies.edit', $company->id)); ?>">Edit</a>
                                          <a class="dropdown-item" href="<?php echo e(route('companies.destroy', $company->id)); ?>" onclick="event.preventDefault();
                                                     document.getElementById('delete-form').submit();"> <?php echo e(__('Delete')); ?> </a>
                                            <form id="delete-form" action="<?php echo e(route('companies.destroy', $company->id)); ?>" method="POST" class="d-none">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                        </div>
                                      </div>
                                </td>
                                <td>
                                    <img src="<?php echo e($company->logo); ?>" class="img-thumbnail"  width="300"
                                    height="200" alt="<?php echo e($company->name); ?>" title="<?php echo e($company->name); ?>">
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
 <?php if (isset($__componentOriginal1c56f069ac3a2d89e930c69e71d82d82f2f427b8)): ?>
<?php $component = $__componentOriginal1c56f069ac3a2d89e930c69e71d82d82f2f427b8; ?>
<?php unset($__componentOriginal1c56f069ac3a2d89e930c69e71d82d82f2f427b8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\xampp74\htdocs\projects\tests\heptagon-test\resources\views/heptagon/admin/company/show.blade.php ENDPATH**/ ?>