<?php $__env->startSection('content'); ?>
    <?php echo e($slot); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp74\htdocs\projects\tests\heptagon-test\resources\views/components/heptagon/app.blade.php ENDPATH**/ ?>