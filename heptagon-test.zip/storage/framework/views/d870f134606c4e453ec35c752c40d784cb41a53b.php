<?php if (isset($component)) { $__componentOriginal1c56f069ac3a2d89e930c69e71d82d82f2f427b8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Heptagon\Layout::class, []); ?>
<?php $component->withName('heptagon.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('pageHeading'); ?> Update <?php echo e($employee->first_name); ?> 's info <span class="float-right"><a href="<?php echo e(route('employees.index')); ?>"><i class="bi bi-arrow-left-circle-fill"></i></a></span> <?php $__env->endSlot(); ?>
    <div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="form-row">
                <div class="col-md-6"><div class="response-message"></div></div>
            </div>
            <div class="h-bg-white">
                <form method="POST" action="<?php echo e(route('employees.update', $employee->id)); ?>" class="needs-validation h-bg-white" id="employeeForm" novalidate>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-row">
                    <div class="col-md-4 mb-3">
                        <label for="status">Company</label>
                        <select class="custom-select" id="status" name="company_id">
                            <option selected disabled value="">Select..</option>
                            <?php if(isset($companies) && $companies->count()): ?>
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($employee) && $employee->company->id == $company->id ?  'selected' : ''); ?> value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <div class="invalid-feedback">
                            Please select status.
                        </div>
                            </div>
                        <div class="col-md-4 mb-3">
                        <label for="firstName">First name</label>
                        <input type="text" class="form-control" id="firstName" name="first_name" value="<?php echo e($employee->first_name); ?>" required>
                        <div class="valid-feedback">
                            Looks good!
                        </div>
                        </div>
                        <div class="col-md-4 mb-3">
                        <label for="lastName">Last name</label>
                        <input type="text" class="form-control" id="lastName" name="last_name" value="<?php echo e($employee->last_name); ?>" required>
                        <div class="valid-feedback">
                            Looks good!
                        </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col-md-3 mb-3">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e($employee->email); ?>" required>
                        <div class="invalid-feedback">
                            Please provide a valid email.
                        </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="phone">Phone</label>
                            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($employee->phone); ?>" required>
                            <div class="invalid-feedback">
                                Please provide a valid phone.
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="designation">Designation</label>
                            <input type="text" class="form-control" id="designation" name="designation" value="<?php echo e($employee->designation); ?>" required>
                            <div class="invalid-feedback">
                                Please enter  designation.
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                        <label for="status">Status</label>
                        <select class="custom-select" id="status" name="status">
                            <option <?php echo e(strtolower($employee->status) == 'active' ? 'selected' : ''); ?> value="active">Active</option>
                            <option <?php echo e(strtolower($employee->status) == 'inactive' ? 'selected' : ''); ?> value="inactive">Inactive</option>
                        </select>
                        <div class="invalid-feedback">
                            Please select status.
                        </div>
                        </div>
                    </div>
                    <button class="btn btn-primary" id="submitAddEmpForm" type="submit">Update employee</button>
                </form>
            </div>
        </div>
    </div>
</div>
 <?php if (isset($__componentOriginal1c56f069ac3a2d89e930c69e71d82d82f2f427b8)): ?>
<?php $component = $__componentOriginal1c56f069ac3a2d89e930c69e71d82d82f2f427b8; ?>
<?php unset($__componentOriginal1c56f069ac3a2d89e930c69e71d82d82f2f427b8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\xampp74\htdocs\projects\tests\heptagon-test\resources\views/heptagon/admin/employee/edit.blade.php ENDPATH**/ ?>